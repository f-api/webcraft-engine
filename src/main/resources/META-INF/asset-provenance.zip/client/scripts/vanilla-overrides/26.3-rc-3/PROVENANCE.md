# Selected original Minecraft 26.3-rc-3 assets

These eight unchanged PNG/model-JSON files are selected fixes over the project's snapshot-7 asset baseline. Mojang/Microsoft retain ownership; existing project Minecraft asset-use approval applies. No claim of original authorship or additional license is made.

Source: https://piston-data.mojang.com/v1/objects/e8f3ef4e54f0eac2e724fb6397bf6d261b9a1af5/client.jar

The official manifest client SHA-1 is e8f3ef4e54f0eac2e724fb6397bf6d261b9a1af5; snapshot-7 base client SHA-1 is 16169fc68cc553b82f495bb2896bde6170aa51a7. `manifest.json` binds both per-file SHA-256 values. `vanilla_asset_overrides.py` applies these files only during asset generation and refuses changed base or replacement bytes. No network requests, classes, worldgen data, or terrain receipts are changed.

Coverage: MC-309468/309501 shelf and shelf-mushroom dropped-item pivots; MC-310087/311151 poplar hanging-sign block texture; MC-310646 unused shelf-mushroom texels; MC-310665 black llama decoration; MC-310710 warm-ocean-ruins map rim. The project's original model/item tints remain in force.
