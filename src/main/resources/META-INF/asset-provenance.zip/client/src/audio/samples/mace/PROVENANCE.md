# Mace and Wind Burst audio provenance

Official Minecraft Java Edition `26.3-snapshot-7` sound files for the mace smash attack and the Wind
Burst enchantment's explosion, taken from Mojang's asset index (the client jar carries no sounds). The
user explicitly approved using original Mojang assets for this work (2026-09-13) and waived licensing
for them, on the same basis as the trial family (`../trial/PROVENANCE.md`) and the title panorama
(`../../../ui/entry/panorama/PROVENANCE.md`). Every other supplied cue keeps the disposition recorded
in `../../THIRD_PARTY_AUDIO.md`.

Chain of pins, each hop verified by `scripts/audio/fetch-mojang-assets.py`:

- version JSON `https://piston-meta.mojang.com/v1/packages/9bcbca292d320f59200957e52805572be62761b4/26.3-snapshot-7.json`
  (SHA-1 `9bcbca292d320f59200957e52805572be62761b4`);
- asset index `33` (SHA-1 `7256d6797a98619a0a0579e3bb7949d2657af4ee`, 597035 bytes);
- `minecraft/sounds.json` (SHA-1 `03df9b7637bff1999da5322a5e92c57ead95a1bd`, 635760 bytes) — the event
  table the runtime mapping follows;
- each object below at `https://resources.download.minecraft.net/<first two hex>/<sha1>`, checked
  against the index SHA-1 and byte length, then against the SHA-256 recorded in
  `scripts/audio/mojang-asset-selection.tsv`.

The 11 files are every file that sounds.json lists for `item.mace.smash_air` (3),
`item.mace.smash_ground` (4), `item.mace.smash_ground_heavy` (1) and `entity.wind_charge.wind_burst`
(3). The mace entries carry no volume or pitch; the three `entity.wind_charge.wind_burst` entries carry
`pitch 1.25` and `attenuation_distance 8`. `item.mace.smash_ground_heavy` shares the
`subtitles.item.mace.smash_ground` subtitle.

| file | asset index object | sha1 (original Ogg) | bytes (Ogg) |
| --- | --- | --- | --- |
| `mace/smash_air_01.webm` | `minecraft/sounds/item/mace/smash_air1.ogg` | `dcdef344e1dff43fd798e3faa41e3ac5e36410f2` | 18247 |
| `mace/smash_air_02.webm` | `minecraft/sounds/item/mace/smash_air2.ogg` | `15f8ff8cda809e33413e5aa428840f37caf15b3c` | 17014 |
| `mace/smash_air_03.webm` | `minecraft/sounds/item/mace/smash_air3.ogg` | `7114c65027e2ef0d8f42a406fa226e513a76ab72` | 17545 |
| `mace/smash_ground_01.webm` | `minecraft/sounds/item/mace/smash_ground1.ogg` | `8f5008b42cf998a0bf391a9772fab8aa69049cac` | 21491 |
| `mace/smash_ground_02.webm` | `minecraft/sounds/item/mace/smash_ground2.ogg` | `9f8089db25a221807d6650835ea6af22659ba4d1` | 21670 |
| `mace/smash_ground_03.webm` | `minecraft/sounds/item/mace/smash_ground3.ogg` | `f0212098e16342cc0270c6b64eaffd7a6edc5c4c` | 24144 |
| `mace/smash_ground_04.webm` | `minecraft/sounds/item/mace/smash_ground4.ogg` | `e747ec6761e14fa3fbb6e9e6c1dacb0891ef52f9` | 25329 |
| `mace/smash_ground_heavy_01.webm` | `minecraft/sounds/item/mace/smash_ground_heavy.ogg` | `c43e28df256051df61e03b9d3ef5908a6c933e88` | 36177 |
| `mace/wind_burst_01.webm` | `minecraft/sounds/entity/wind_charge/wind_burst1.ogg` | `22b61f8192748c33e482b973edd993eed7c405da` | 14478 |
| `mace/wind_burst_02.webm` | `minecraft/sounds/entity/wind_charge/wind_burst2.ogg` | `839b5c67010398d2e655500b498e9931e9a30ce1` | 12663 |
| `mace/wind_burst_03.webm` | `minecraft/sounds/entity/wind_charge/wind_burst3.ogg` | `55ffa7726f8f2603fea7c0db2b27633a49b3fe20` | 11676 |

Rendering: `scripts/audio/encode-mojang-assets.sh <output>` fetches and pin-checks the inputs, then runs
the unchanged `encode-selected.sh` chain — the strict `verify-selected-inputs.py` preflight and the same
`loudnorm=I=-20:LRA=11:TP=-2` + true-peak limiter chain into 48 kHz mono Opus (40 kbps VBR, WebM) as
every other pinned sample. Output SHA-256s are in `scripts/audio/inventory-sha256.tsv`. The runtime
mapping — per-event file lists, the PLAYERS category of the smash events and the Wind Burst range
(4 × 8 = 32) and file pitch 1.25 — lives in `../../SampleCatalog.ts` and `../../SemanticSoundRegistry.ts`.
