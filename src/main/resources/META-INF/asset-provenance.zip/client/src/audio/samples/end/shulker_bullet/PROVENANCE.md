# Shulker bullet audio provenance

Official Minecraft Java Edition `26.3-snapshot-7` sound files taken from Mojang's asset index (the client jar
carries no sounds). The user explicitly approved using original Mojang assets for the End dimension, end
cities, villagers and raids and waived licensing for them, on the same basis as the title panorama
(`../../../../ui/entry/panorama/PROVENANCE.md`) and the trial spawner family (`../../trial/PROVENANCE.md`).

Chain of pins, each hop verified by `scripts/audio/fetch-mojang-assets.py`: version JSON
`9bcbca292d320f59200957e52805572be62761b4`, asset index `33` (`7256d6797a98619a0a0579e3bb7949d2657af4ee`),
`minecraft/sounds.json` (`03df9b7637bff1999da5322a5e92c57ead95a1bd`), then each object below by its index
SHA-1 and byte length and the SHA-256 recorded in `scripts/audio/mojang-asset-selection.tsv`. Encoded by
`scripts/audio/encode-mojang-assets.sh` (loudnorm, true-peak limit, 48 kHz mono Opus at the manifest bitrate).

sounds.json maps both `entity.shulker_bullet.hit` and `entity.shulker_bullet.hurt` to these four files.

| file | asset index object | sha1 (original Ogg) | bytes (Ogg) | sounds.json events |
| --- | --- | --- | --- | --- |
| `end/shulker_bullet/hit_01.webm` | `minecraft/sounds/entity/shulker_bullet/hit1.ogg` | `9340adb5c86230146f204c26a13c052626a8ad9e` | 11668 | entity.shulker_bullet.hit,entity.shulker_bullet.hurt |
| `end/shulker_bullet/hit_02.webm` | `minecraft/sounds/entity/shulker_bullet/hit2.ogg` | `888dc3e9ae0fb74109b2e79020919a4ebfd7dd66` | 11469 | entity.shulker_bullet.hit,entity.shulker_bullet.hurt |
| `end/shulker_bullet/hit_03.webm` | `minecraft/sounds/entity/shulker_bullet/hit3.ogg` | `17b7dff9e88b7b32613ce678a0c29020e4b5ce93` | 12468 | entity.shulker_bullet.hit,entity.shulker_bullet.hurt |
| `end/shulker_bullet/hit_04.webm` | `minecraft/sounds/entity/shulker_bullet/hit4.ogg` | `6d4188e3c7b26a4dca657f9f047383deccf6ec73` | 9345 | entity.shulker_bullet.hit,entity.shulker_bullet.hurt |
