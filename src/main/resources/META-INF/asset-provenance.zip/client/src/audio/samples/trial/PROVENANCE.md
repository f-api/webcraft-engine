# Trial spawner, vault and heavy core audio provenance

Official Minecraft Java Edition `26.3-snapshot-7` sound files for the trial spawner, the vault and the
heavy core, taken from Mojang's asset index (the client jar carries no sounds). The user explicitly
approved using these original Mojang assets and waived licensing for them, on the same basis as the
title panorama (`../../../ui/entry/panorama/PROVENANCE.md`). This is the one family in the sample set
that is Mojang original audio; every other supplied cue keeps the disposition recorded in
`../../THIRD_PARTY_AUDIO.md`.

Chain of pins, each hop verified by `scripts/audio/fetch-mojang-assets.py`:

- version JSON `https://piston-meta.mojang.com/v1/packages/9bcbca292d320f59200957e52805572be62761b4/26.3-snapshot-7.json`
  (SHA-1 `9bcbca292d320f59200957e52805572be62761b4`);
- asset index `33` (SHA-1 `7256d6797a98619a0a0579e3bb7949d2657af4ee`, 597035 bytes);
- `minecraft/sounds.json` (SHA-1 `03df9b7637bff1999da5322a5e92c57ead95a1bd`, 635760 bytes) — the event
  table the runtime mapping follows;
- each object below at `https://resources.download.minecraft.net/<first two hex>/<sha1>`, checked
  against the index SHA-1 and byte length, then against the SHA-256 recorded in
  `scripts/audio/mojang-asset-selection.tsv`.

The 75 files are every distinct file that sounds.json lists for an event whose name starts with
`block.trial_spawner.`, `block.vault.` or `block.heavy_core.` (35 events). Events sharing a file point
at the same output: `hit` and `fall` use the `step` files, `block.heavy_core.place` uses the heavy core
`break` files, and `block.vault.close_shutter` uses `block/trial_spawner/close_shutter`.

| file | asset index object | sha1 (original Ogg) | bytes (Ogg) |
| --- | --- | --- | --- |
| `trial/heavy_core/break_01.webm` | `minecraft/sounds/block/heavy_core/break1.ogg` | `8b4ac501a75c7a3f64b2a822b1f099a828ea8297` | 7738 |
| `trial/heavy_core/break_02.webm` | `minecraft/sounds/block/heavy_core/break2.ogg` | `2f5ef01938e2150b020e84704f8f1d1097dc8879` | 8152 |
| `trial/heavy_core/break_03.webm` | `minecraft/sounds/block/heavy_core/break3.ogg` | `9c80b75f314a4da35fe312c4455577526e0098ab` | 7322 |
| `trial/heavy_core/break_04.webm` | `minecraft/sounds/block/heavy_core/break4.ogg` | `77b0b1385766ddfaf61bf952bf4bc056fb594782` | 8059 |
| `trial/heavy_core/step_01.webm` | `minecraft/sounds/block/heavy_core/step1.ogg` | `3558e4e13ba3829cc69f1268581e30b962416816` | 6406 |
| `trial/heavy_core/step_02.webm` | `minecraft/sounds/block/heavy_core/step2.ogg` | `c22a772466a47677068b27ce20486ce225944ae0` | 5837 |
| `trial/heavy_core/step_03.webm` | `minecraft/sounds/block/heavy_core/step3.ogg` | `b2c137da3b3c4a462af349c2e12eaf54e2c6f86a` | 5767 |
| `trial/heavy_core/step_04.webm` | `minecraft/sounds/block/heavy_core/step4.ogg` | `01e0a7d49b42e9544735260401c6fc23247f72f7` | 6119 |
| `trial/trial_spawner/about_to_spawn_item_01.webm` | `minecraft/sounds/block/trial_spawner/about_to_spawn_item.ogg` | `7f09c286de0c2a186c84eb67c777ad35a50562e9` | 28646 |
| `trial/trial_spawner/ambient_01.webm` | `minecraft/sounds/block/trial_spawner/ambient1.ogg` | `39143ab7c257c5b1138448103fecf73c8e001fa5` | 25400 |
| `trial/trial_spawner/ambient_02.webm` | `minecraft/sounds/block/trial_spawner/ambient2.ogg` | `015b6ad7c08735a7856ce404b33ddce317d4c23a` | 23525 |
| `trial/trial_spawner/ambient_03.webm` | `minecraft/sounds/block/trial_spawner/ambient3.ogg` | `a484516c7a1a86a82cc393790ba5d0b635eada65` | 21284 |
| `trial/trial_spawner/ambient_04.webm` | `minecraft/sounds/block/trial_spawner/ambient4.ogg` | `e78d997b02f91f36876f65a7aa6ec4fd86142366` | 22043 |
| `trial/trial_spawner/ambient_05.webm` | `minecraft/sounds/block/trial_spawner/ambient5.ogg` | `ad001047a1b15e067500bbf3c0cb90095eb69684` | 27150 |
| `trial/trial_spawner/ambient_ominous_01.webm` | `minecraft/sounds/block/trial_spawner/ambient_ominous1.ogg` | `04430b2c137aaae37241228c6bfeea8e62cf48b5` | 32113 |
| `trial/trial_spawner/ambient_ominous_02.webm` | `minecraft/sounds/block/trial_spawner/ambient_ominous2.ogg` | `e003cae940c726ae24f198f3d0745f78abac14ad` | 34916 |
| `trial/trial_spawner/ambient_ominous_03.webm` | `minecraft/sounds/block/trial_spawner/ambient_ominous3.ogg` | `e82282aebe27217e74878c179a3b45c335e7cf38` | 36199 |
| `trial/trial_spawner/ambient_ominous_04.webm` | `minecraft/sounds/block/trial_spawner/ambient_ominous4.ogg` | `092db8449ed085eb9b764c9ab1adc829ee4e2300` | 40583 |
| `trial/trial_spawner/ambient_ominous_05.webm` | `minecraft/sounds/block/trial_spawner/ambient_ominous5.ogg` | `0a9d177aa4fb5896b3125f6aea8eadf62c7260dd` | 31370 |
| `trial/trial_spawner/break_01.webm` | `minecraft/sounds/block/trial_spawner/break1.ogg` | `4d89f4dce1ef82cdd930f10f9dcbc3f1e3cf24a6` | 17015 |
| `trial/trial_spawner/break_02.webm` | `minecraft/sounds/block/trial_spawner/break2.ogg` | `d181fa75f01a291979f9103d7cd7473631fb5e8c` | 17513 |
| `trial/trial_spawner/break_03.webm` | `minecraft/sounds/block/trial_spawner/break3.ogg` | `a6cc7f68228c91f8e692144464f48ece318e9a11` | 18689 |
| `trial/trial_spawner/close_shutter_01.webm` | `minecraft/sounds/block/trial_spawner/close_shutter.ogg` | `7356e0a396a34eaa3e882923d3968f4b2e5e4651` | 6215 |
| `trial/trial_spawner/detect_player_01.webm` | `minecraft/sounds/block/trial_spawner/detect_player1.ogg` | `1094a96acf2f61274676d345505c4a5ef75c6b94` | 19859 |
| `trial/trial_spawner/detect_player_02.webm` | `minecraft/sounds/block/trial_spawner/detect_player2.ogg` | `02332b417ec91b279ecdd49923f2e162d87bfea4` | 21354 |
| `trial/trial_spawner/detect_player_03.webm` | `minecraft/sounds/block/trial_spawner/detect_player3.ogg` | `a6f81cd44a241516d9ce835e6f9e75e62436cdeb` | 22316 |
| `trial/trial_spawner/eject_item_01.webm` | `minecraft/sounds/block/trial_spawner/eject_item1.ogg` | `98c94b78a3538392ec63314bd00b6fdd02277a1e` | 14327 |
| `trial/trial_spawner/ominous_activate_01.webm` | `minecraft/sounds/block/trial_spawner/ominous_activate.ogg` | `59b77eaabf6ba4415b71f760638917e891d22336` | 29654 |
| `trial/trial_spawner/open_shutter_01.webm` | `minecraft/sounds/block/trial_spawner/open_shutter.ogg` | `70c7e704472d19e92b606eac1d71250c3e69dd40` | 24938 |
| `trial/trial_spawner/place_01.webm` | `minecraft/sounds/block/trial_spawner/place1.ogg` | `3e56f0d658620d97b10cc9a7e5483eb940ed2e08` | 14932 |
| `trial/trial_spawner/place_02.webm` | `minecraft/sounds/block/trial_spawner/place2.ogg` | `5b13f3f71578e30012b3f30cc0057f8c846118c2` | 15747 |
| `trial/trial_spawner/place_03.webm` | `minecraft/sounds/block/trial_spawner/place3.ogg` | `89bbd7da47d332ed514e65631bcea79fcfa32efc` | 13593 |
| `trial/trial_spawner/spawn_01.webm` | `minecraft/sounds/block/trial_spawner/spawn1.ogg` | `f95e9a960a796d7582c3cebff6fe3e5333164911` | 16832 |
| `trial/trial_spawner/spawn_02.webm` | `minecraft/sounds/block/trial_spawner/spawn2.ogg` | `4904ea79799cddee7169cef551c0d09450ac31bd` | 20767 |
| `trial/trial_spawner/spawn_03.webm` | `minecraft/sounds/block/trial_spawner/spawn3.ogg` | `8f6d15acc509936941efdc566b60c66365b1561e` | 20802 |
| `trial/trial_spawner/spawn_04.webm` | `minecraft/sounds/block/trial_spawner/spawn4.ogg` | `abbb3a6b3bfe83e1c3e75db04580d6bdd0adbcaf` | 20138 |
| `trial/trial_spawner/spawn_item_01.webm` | `minecraft/sounds/block/trial_spawner/spawn_item1.ogg` | `487799e00e80d0706f1284df3fc8c7805bb325d4` | 25371 |
| `trial/trial_spawner/spawn_item_02.webm` | `minecraft/sounds/block/trial_spawner/spawn_item2.ogg` | `eaaf823192b61a168b20839da313ce62bd060ef9` | 25073 |
| `trial/trial_spawner/spawn_item_03.webm` | `minecraft/sounds/block/trial_spawner/spawn_item3.ogg` | `67abd16cada0ff493b373ba04aedbc11411cd890` | 25434 |
| `trial/trial_spawner/spawn_item_begin_01.webm` | `minecraft/sounds/block/trial_spawner/spawn_item_begin1.ogg` | `567755439fc5118a0ede2e191a552ca0c1db8d25` | 23327 |
| `trial/trial_spawner/spawn_item_begin_02.webm` | `minecraft/sounds/block/trial_spawner/spawn_item_begin2.ogg` | `45986752eaebf2c004da7e1e297df0ccf55c929e` | 30293 |
| `trial/trial_spawner/spawn_item_begin_03.webm` | `minecraft/sounds/block/trial_spawner/spawn_item_begin3.ogg` | `2368a0e0b26e33051af360cc4c14cfdcf6246bc0` | 27367 |
| `trial/trial_spawner/step_01.webm` | `minecraft/sounds/block/trial_spawner/step1.ogg` | `b20c57049e28e3c972ed280532f021440e91fa42` | 6590 |
| `trial/trial_spawner/step_02.webm` | `minecraft/sounds/block/trial_spawner/step2.ogg` | `1618d8c9a2d0b3afe5d244aa0c4a3123ce9bb0fb` | 6488 |
| `trial/trial_spawner/step_03.webm` | `minecraft/sounds/block/trial_spawner/step3.ogg` | `cfe9c216f6d2c028106bbadd6fee985f896fa771` | 6435 |
| `trial/trial_spawner/step_04.webm` | `minecraft/sounds/block/trial_spawner/step4.ogg` | `0fb1c24c2ac7866392f1a2d441cd4416d41723eb` | 6380 |
| `trial/trial_spawner/step_05.webm` | `minecraft/sounds/block/trial_spawner/step5.ogg` | `58930c612add179d3954cdeabdf6894d11eec1c6` | 6675 |
| `trial/vault/activate_01.webm` | `minecraft/sounds/block/vault/activate.ogg` | `92dab48dc7436bd2b2cc564c9190f934f9fd5463` | 14535 |
| `trial/vault/ambient_01.webm` | `minecraft/sounds/block/vault/ambient1.ogg` | `e9644deaba05299e6f119096a892366b06a92727` | 28649 |
| `trial/vault/ambient_02.webm` | `minecraft/sounds/block/vault/ambient2.ogg` | `1ee3efc2dd4121176b542c96fcc7baf6d3badd13` | 27058 |
| `trial/vault/ambient_03.webm` | `minecraft/sounds/block/vault/ambient3.ogg` | `f856295d6812e739fbdf42056f3e1814cf2a76ab` | 21904 |
| `trial/vault/break_01.webm` | `minecraft/sounds/block/vault/break1.ogg` | `9175b581230b552217fe55f19830d359a435ced6` | 15402 |
| `trial/vault/break_02.webm` | `minecraft/sounds/block/vault/break2.ogg` | `92e6c376ee2745b5e05d3ac1820bedfa417f2ee4` | 16564 |
| `trial/vault/break_03.webm` | `minecraft/sounds/block/vault/break3.ogg` | `8c515ed4795bb3d7aed1b86849ba65703edf1306` | 15178 |
| `trial/vault/break_04.webm` | `minecraft/sounds/block/vault/break4.ogg` | `e1940bfcf38822799cd81279f642e0ec13920923` | 14507 |
| `trial/vault/deactivate_01.webm` | `minecraft/sounds/block/vault/deactivate.ogg` | `86db10084162de0f4e27fe2df10b67e33898760e` | 15954 |
| `trial/vault/eject_01.webm` | `minecraft/sounds/block/vault/eject1.ogg` | `f73a43d391dae371010eecfa517fac11d08507f3` | 16549 |
| `trial/vault/eject_02.webm` | `minecraft/sounds/block/vault/eject2.ogg` | `e676c2c8b9653ba25c46993aafd5c9afce671785` | 15850 |
| `trial/vault/eject_03.webm` | `minecraft/sounds/block/vault/eject3.ogg` | `317a73002f87d331c31885720e84a0a081e06998` | 16868 |
| `trial/vault/insert_01.webm` | `minecraft/sounds/block/vault/insert.ogg` | `097eabe5a18ccfcc253e23550b596bd2a5746649` | 13385 |
| `trial/vault/insert_fail_01.webm` | `minecraft/sounds/block/vault/insert_fail.ogg` | `5b8a1ac9caa777cc31443a08654f5044b979aad7` | 11672 |
| `trial/vault/open_shutter_01.webm` | `minecraft/sounds/block/vault/open_shutter.ogg` | `4158d20271c062b43a0a8081acdf0937221cceb1` | 24165 |
| `trial/vault/place_01.webm` | `minecraft/sounds/block/vault/place1.ogg` | `4470661621cf0e95abdac0b099ece7d8bb308020` | 8298 |
| `trial/vault/place_02.webm` | `minecraft/sounds/block/vault/place2.ogg` | `8e6265fa36f3494f01c87c7de1d5be3ce3f4255b` | 7854 |
| `trial/vault/place_03.webm` | `minecraft/sounds/block/vault/place3.ogg` | `64daa28cc72b76a3516f8291fa929e5c2702f4dc` | 7202 |
| `trial/vault/place_04.webm` | `minecraft/sounds/block/vault/place4.ogg` | `2ed55ab3b9df49cb57662b483a9fa40403d380a5` | 7499 |
| `trial/vault/reject_rewarded_player_01.webm` | `minecraft/sounds/block/vault/reject_rewarded_player.ogg` | `9a4bfa8eeb8f34803bf89e55eee3fb062e9bbac6` | 15232 |
| `trial/vault/step_01.webm` | `minecraft/sounds/block/vault/step1.ogg` | `d25f44424805b208ce77aad6a1898d55831d47ab` | 10389 |
| `trial/vault/step_02.webm` | `minecraft/sounds/block/vault/step2.ogg` | `0828348eb05a0e1b232f6b091b8598e2123f9a43` | 8951 |
| `trial/vault/step_03.webm` | `minecraft/sounds/block/vault/step3.ogg` | `bc490285ee3c28a5ad8dfadd42a2b6974690a430` | 8921 |
| `trial/vault/step_04.webm` | `minecraft/sounds/block/vault/step4.ogg` | `ea3c8dba058142c1ff38d7dd49895f5b8b037baa` | 9196 |
| `trial/vault/step_05.webm` | `minecraft/sounds/block/vault/step5.ogg` | `88378c5a24a6cd1f8c543ddaa08988bab2ac2eb9` | 10008 |
| `trial/vault/step_06.webm` | `minecraft/sounds/block/vault/step6.ogg` | `614d534c219fe77929fe81d642dc783f3ed7e6c1` | 10132 |
| `trial/vault/step_07.webm` | `minecraft/sounds/block/vault/step7.ogg` | `eb500c65f1c33130ab0f29a8b7432a4bfe2187e0` | 9940 |
| `trial/vault/step_08.webm` | `minecraft/sounds/block/vault/step8.ogg` | `1aa54bf9d3ce024643a7dea98d5d82ffe4ca4e6e` | 9823 |

Every output was re-encoded by `scripts/audio/encode-mojang-assets.sh` (FFmpeg 8.0.1): it runs the
fetcher, then `encode-selected.sh` with `AUDIO_SELECTION_MANIFEST=mojang-asset-selection.tsv` and
`AUDIO_SOURCE_ROOT` at the fetched `minecraft/sounds` tree, so these rows pass the same strict
`verify-selected-inputs.py` preflight and the same `loudnorm=I=-20:LRA=11:TP=-2` + true-peak limiter
chain into 48 kHz mono Opus (40 kbps VBR, WebM) as every other pinned sample. Output SHA-256s are in
`scripts/audio/inventory-sha256.tsv`. The runtime mapping — per-event file lists, the
`block.trial_spawner.break` file volume 0.9 and the `block.trial_spawner.detect_player` pitch 0.95
entries — lives in `../../SampleCatalog.ts`, `../../SemanticSoundRegistry.ts` and `../../AudioEngine.ts`.
