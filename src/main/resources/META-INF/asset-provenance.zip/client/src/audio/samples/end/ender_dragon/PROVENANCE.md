# Ender dragon fight audio provenance

Official Minecraft Java Edition `26.3-snapshot-7` sound files for the ender dragon, the dragon's breath
bottle and the End boss music, taken from Mojang's asset index (the client jar carries no sounds). The
user explicitly approved using original Mojang assets for the End dimension and waived licensing for
them, on the same basis as the title panorama (`../../../../ui/entry/panorama/PROVENANCE.md`) and the
trial spawner family (`../../trial/PROVENANCE.md`).

Chain of pins, each hop verified by `scripts/audio/fetch-mojang-assets.py`:

- version JSON `https://piston-meta.mojang.com/v1/packages/9bcbca292d320f59200957e52805572be62761b4/26.3-snapshot-7.json`
  (SHA-1 `9bcbca292d320f59200957e52805572be62761b4`);
- asset index `33` (SHA-1 `7256d6797a98619a0a0579e3bb7949d2657af4ee`);
- `minecraft/sounds.json` (SHA-1 `03df9b7637bff1999da5322a5e92c57ead95a1bd`) — the event table the runtime
  mapping follows;
- each object below at `https://resources.download.minecraft.net/<first two hex>/<sha1>`, checked
  against the index SHA-1 and byte length, then against the SHA-256 recorded in
  `scripts/audio/mojang-asset-selection.tsv`.

The 18 files here plus one shared `samples/vanilla` output are every distinct file that sounds.json lists for `entity.ender_dragon.ambient`,
`entity.ender_dragon.death`, `entity.ender_dragon.flap`, `entity.ender_dragon.growl`,
`entity.ender_dragon.hurt`, `entity.ender_dragon.shoot`, `item.bottle.fill_dragonbreath` and
`music.dragon`. `ambient` and `growl` share the four growl files. `shoot` is `mob/ghast/fireball4`, whose
render is byte-identical to `vanilla/mob/ghast/fireball4.webm`, so the catalog plays that file.
`entity.dragon_fireball.explode` lists `random/explode1..4`, played from `vanilla/random/explode1..4.webm`
(the same files as `entity.generic.explode`).

The boss music output applies an absolute Opus header gain of -1136 Q8 dB (-4.4375 dB),
reducing its decoded amplitude to 59.996% of the previous file without re-encoding its audio packets.
`encode-selected.sh` applies this after normalization on every regeneration; dragon effects are unchanged.

| file | asset index object | sha1 (original Ogg) | bytes (Ogg) |
| --- | --- | --- | --- |
| `end/ender_dragon/growl_01.webm` | `minecraft/sounds/mob/enderdragon/growl1.ogg` | `b5f9d965c227474231582b52f14f8167b97bf476` | 29909 |
| `end/ender_dragon/growl_02.webm` | `minecraft/sounds/mob/enderdragon/growl2.ogg` | `b814e7cbcdd572ed7f926a947250d009f206c07b` | 30591 |
| `end/ender_dragon/growl_03.webm` | `minecraft/sounds/mob/enderdragon/growl3.ogg` | `37e634797f199982107aa7d296a0f14d69135227` | 32839 |
| `end/ender_dragon/growl_04.webm` | `minecraft/sounds/mob/enderdragon/growl4.ogg` | `c263ae99db287bd803591b0b6cd7865435e6c54a` | 28533 |
| `end/ender_dragon/end_01.webm` | `minecraft/sounds/mob/enderdragon/end.ogg` | `76dd4983249264ab1f4779145118bb162b0d884a` | 263913 |
| `end/ender_dragon/hit_01.webm` | `minecraft/sounds/mob/enderdragon/hit1.ogg` | `59cc1d9f09157d334c52db5b79da04f8d56c11bf` | 12273 |
| `end/ender_dragon/hit_02.webm` | `minecraft/sounds/mob/enderdragon/hit2.ogg` | `1933ea18af228a0d39e26c554adb396acdaee05b` | 11606 |
| `end/ender_dragon/hit_03.webm` | `minecraft/sounds/mob/enderdragon/hit3.ogg` | `4634e0b38a0062a9e52a6079773bf252fb421761` | 11834 |
| `end/ender_dragon/hit_04.webm` | `minecraft/sounds/mob/enderdragon/hit4.ogg` | `d3df4915f7e23b900d472dba0468df0065ebc7ae` | 11586 |
| `end/ender_dragon/wings_01.webm` | `minecraft/sounds/mob/enderdragon/wings1.ogg` | `b2a6162b783a62cffabc2bd58e79e383b5c70a8d` | 11312 |
| `end/ender_dragon/wings_02.webm` | `minecraft/sounds/mob/enderdragon/wings2.ogg` | `2f25e83bbfac230b610691e174dc7440101ed279` | 11500 |
| `end/ender_dragon/wings_03.webm` | `minecraft/sounds/mob/enderdragon/wings3.ogg` | `e4741020ec40e539b87e1339570e6453d3812e1e` | 11103 |
| `end/ender_dragon/wings_04.webm` | `minecraft/sounds/mob/enderdragon/wings4.ogg` | `8bcda486ff6fdb2c2c4532da72e6d71536779853` | 12572 |
| `end/ender_dragon/wings_05.webm` | `minecraft/sounds/mob/enderdragon/wings5.ogg` | `4518fdf76b94647009cc6e2463e12743c44c3118` | 12372 |
| `end/ender_dragon/wings_06.webm` | `minecraft/sounds/mob/enderdragon/wings6.ogg` | `7bd37531acf96c978dc484e84dbdfc5bd11c05c1` | 12016 |
| `end/bottle/fill_dragonbreath_01.webm` | `minecraft/sounds/item/bottle/fill_dragonbreath1.ogg` | `f13041d4e6aa259fd660b555563329d4be7d490f` | 8659 |
| `end/bottle/fill_dragonbreath_02.webm` | `minecraft/sounds/item/bottle/fill_dragonbreath2.ogg` | `31718790d69993ec588f16daf43f48c2feb0ff59` | 7131 |
| `end/music/boss_01.webm` | `minecraft/sounds/music/game/end/boss.ogg` | `67e25166bfe3e0ce3ef45ce2680b2413f80ccc5a` | 3761170 |

Every output was re-encoded by `scripts/audio/encode-selected.sh` (FFmpeg 8.0.1) with
`AUDIO_SELECTION_MANIFEST=mojang-asset-selection.tsv` and `AUDIO_SOURCE_ROOT` at the fetched
`minecraft/sounds` tree — the same strict `verify-selected-inputs.py` preflight and the same
`loudnorm=I=-20:LRA=11:TP=-2` + true-peak limiter chain into 48 kHz mono Opus (40 kbps VBR, WebM) as
every other pinned sample. The music track (`music/game/end/boss.ogg`, 344 s stereo) uses the lowest
bitrate the chain allows (40 kbps mono, 1 994 032 bytes) because every sample is embedded in the single
HTML; it is streamed through an `<audio>` element rather than decoded whole
(`../../../MusicDirector.ts`). Output SHA-256s are in `scripts/audio/inventory-sha256.tsv`.
