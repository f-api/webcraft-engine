# End city shulker audio provenance

Official Minecraft Java Edition `26.3-snapshot-7` sound files taken from Mojang's asset index (the client jar
carries no sounds). The user explicitly approved using original Mojang assets for the End dimension, end
cities, villagers and raids and waived licensing for them, on the same basis as the title panorama
(`../../../../ui/entry/panorama/PROVENANCE.md`) and the trial spawner family (`../../trial/PROVENANCE.md`).

Chain of pins, each hop verified by `scripts/audio/fetch-mojang-assets.py`: version JSON
`9bcbca292d320f59200957e52805572be62761b4`, asset index `33` (`7256d6797a98619a0a0579e3bb7949d2657af4ee`),
`minecraft/sounds.json` (`03df9b7637bff1999da5322a5e92c57ead95a1bd`), then each object below by its index
SHA-1 and byte length and the SHA-256 recorded in `scripts/audio/mojang-asset-selection.tsv`. Encoded by
`scripts/audio/encode-mojang-assets.sh` (loudnorm, true-peak limit, 48 kHz mono Opus at the manifest bitrate).

The runtime registers every `entity.shulker.*` event on these files; `entity.shulker.teleport` uses the two enderman portal files exactly as sounds.json does.

| file | asset index object | sha1 (original Ogg) | bytes (Ogg) | sounds.json events |
| --- | --- | --- | --- | --- |
| `end/shulker/ambient_01.webm` | `minecraft/sounds/entity/shulker/ambient1.ogg` | `95dca0416258364d90649392592d470eb800b17c` | 7620 | entity.shulker.ambient |
| `end/shulker/ambient_02.webm` | `minecraft/sounds/entity/shulker/ambient2.ogg` | `f1a522b5bea10dbb48e49279c1358e71846d3a92` | 7816 | entity.shulker.ambient |
| `end/shulker/ambient_03.webm` | `minecraft/sounds/entity/shulker/ambient3.ogg` | `1829db3d900fde5a1f118286c7b437ebc48c06d3` | 6646 | entity.shulker.ambient |
| `end/shulker/ambient_04.webm` | `minecraft/sounds/entity/shulker/ambient4.ogg` | `b04022583d2d085a769e14ca7b7ea6566f326d58` | 8112 | entity.shulker.ambient |
| `end/shulker/ambient_05.webm` | `minecraft/sounds/entity/shulker/ambient5.ogg` | `0e533ac4f54c97288ac1f1d207ae185f1059f6ea` | 7566 | entity.shulker.ambient |
| `end/shulker/ambient_06.webm` | `minecraft/sounds/entity/shulker/ambient6.ogg` | `5fd4f3fd1c07f8c03452c27c8a188c2947a96f75` | 7925 | entity.shulker.ambient |
| `end/shulker/ambient_07.webm` | `minecraft/sounds/entity/shulker/ambient7.ogg` | `a12177b8cb7844ed33eac78576c4fb43cebad4b9` | 8731 | entity.shulker.ambient |
| `end/shulker/close_01.webm` | `minecraft/sounds/entity/shulker/close1.ogg` | `5561ce870837ae106a6ff0b6186d04f726aeafc6` | 5862 | entity.shulker.close |
| `end/shulker/close_02.webm` | `minecraft/sounds/entity/shulker/close2.ogg` | `5f98c736907655a48944c763657a38d472416d6e` | 5704 | entity.shulker.close |
| `end/shulker/close_03.webm` | `minecraft/sounds/entity/shulker/close3.ogg` | `d4d7803c440c4ae44ffb49803ab2b8aaf7a137ae` | 5910 | entity.shulker.close |
| `end/shulker/close_04.webm` | `minecraft/sounds/entity/shulker/close4.ogg` | `031e80a9c2aa7455df9c9092e2136cd94e5bd6b9` | 5483 | entity.shulker.close |
| `end/shulker/close_05.webm` | `minecraft/sounds/entity/shulker/close5.ogg` | `da1ba3ff3110d6ea777251c88ea77bcf35168c80` | 5767 | entity.shulker.close |
| `end/shulker/death_01.webm` | `minecraft/sounds/entity/shulker/death1.ogg` | `5a2a953165cac17c014e9da4c202f1efde19ec46` | 14094 | entity.shulker.death |
| `end/shulker/death_02.webm` | `minecraft/sounds/entity/shulker/death2.ogg` | `3d8274d3fe03f28abb559e08505202ca5261ae47` | 11844 | entity.shulker.death |
| `end/shulker/death_03.webm` | `minecraft/sounds/entity/shulker/death3.ogg` | `f8608dc8085c9c70ce8f40e039b950c10359ab8b` | 10211 | entity.shulker.death |
| `end/shulker/death_04.webm` | `minecraft/sounds/entity/shulker/death4.ogg` | `b7ddd5ef5c3c487e586827bc9a879261e397c726` | 12069 | entity.shulker.death |
| `end/shulker/hurt_01.webm` | `minecraft/sounds/entity/shulker/hurt1.ogg` | `05b10bf6d4554c28cb2fbd0ed85a505e92140e2e` | 6133 | entity.shulker.hurt |
| `end/shulker/hurt_02.webm` | `minecraft/sounds/entity/shulker/hurt2.ogg` | `12edc7d00dc3c2ee5d82f26875be77586c46a7ed` | 6771 | entity.shulker.hurt |
| `end/shulker/hurt_03.webm` | `minecraft/sounds/entity/shulker/hurt3.ogg` | `e4df499058ce4b7f52801a7b6966de47c948feee` | 6888 | entity.shulker.hurt |
| `end/shulker/hurt_04.webm` | `minecraft/sounds/entity/shulker/hurt4.ogg` | `80c1c8a3de011b5c08169f0c532c272ca586d355` | 6499 | entity.shulker.hurt |
| `end/shulker/hurt_closed_01.webm` | `minecraft/sounds/entity/shulker/hurt_closed1.ogg` | `db24df80329e9c1ac4566a0ed20029d312002409` | 4983 | entity.shulker.hurt_closed |
| `end/shulker/hurt_closed_02.webm` | `minecraft/sounds/entity/shulker/hurt_closed2.ogg` | `5722548545b3405acfe280a74e88471517bc7bb1` | 5245 | entity.shulker.hurt_closed |
| `end/shulker/hurt_closed_03.webm` | `minecraft/sounds/entity/shulker/hurt_closed3.ogg` | `2d67535d719b7485f2a97b1f397051302d3ad1cd` | 4942 | entity.shulker.hurt_closed |
| `end/shulker/hurt_closed_04.webm` | `minecraft/sounds/entity/shulker/hurt_closed4.ogg` | `511fce760d0a64353a839f456f4225783be344bc` | 5127 | entity.shulker.hurt_closed |
| `end/shulker/hurt_closed_05.webm` | `minecraft/sounds/entity/shulker/hurt_closed5.ogg` | `8aaaa5fc3424da6ad9cd5fb3954c4fc798064dd0` | 5134 | entity.shulker.hurt_closed |
| `end/shulker/open_01.webm` | `minecraft/sounds/entity/shulker/open1.ogg` | `39dd58da1447613afebbfbd099a551663ac442bc` | 5860 | entity.shulker.open |
| `end/shulker/open_02.webm` | `minecraft/sounds/entity/shulker/open2.ogg` | `466465961daca3ad95d498fe34aace460ed4c8a4` | 5492 | entity.shulker.open |
| `end/shulker/open_03.webm` | `minecraft/sounds/entity/shulker/open3.ogg` | `67ed08f926da4c66424152f639f5da65caac3ce4` | 5542 | entity.shulker.open |
| `end/shulker/open_04.webm` | `minecraft/sounds/entity/shulker/open4.ogg` | `98155943b8d35f365d0d2a03b0c5d36d303f5e7b` | 5494 | entity.shulker.open |
| `end/shulker/open_05.webm` | `minecraft/sounds/entity/shulker/open5.ogg` | `11abcda449b0ca4aca0244552413a2eac6c3f3bd` | 5613 | entity.shulker.open |
| `end/shulker/shoot_01.webm` | `minecraft/sounds/entity/shulker/shoot1.ogg` | `cc94a15dca4384c3c315ec98628648fb291f17d7` | 15427 | entity.shulker.shoot |
| `end/shulker/shoot_02.webm` | `minecraft/sounds/entity/shulker/shoot2.ogg` | `d17a3b165c758f5f7e63af5c7141aa60602930e2` | 15116 | entity.shulker.shoot |
| `end/shulker/shoot_03.webm` | `minecraft/sounds/entity/shulker/shoot3.ogg` | `79c2e2711a546a1867b46ef2b81d8d410107f18d` | 14533 | entity.shulker.shoot |
| `end/shulker/shoot_04.webm` | `minecraft/sounds/entity/shulker/shoot4.ogg` | `972034032fd6d1b684830976337f8e9db87c7337` | 16092 | entity.shulker.shoot |
| `end/shulker/portal_01.webm` | `minecraft/sounds/mob/endermen/portal.ogg` | `15eb7f0940b43b5422524c8f20db44b72b310233` | 11343 | entity.shulker.teleport |
| `end/shulker/portal_02.webm` | `minecraft/sounds/mob/endermen/portal2.ogg` | `e513adbd9b3ea95b7c2d5726c8ae7a5f497e0328` | 8158 | entity.shulker.teleport |
