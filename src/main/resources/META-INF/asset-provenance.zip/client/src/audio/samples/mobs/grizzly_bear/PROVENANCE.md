# Grizzly bear voice provenance

Eight dedicated encoded derivatives of the approved repository brown bear voice
samples. The parents are procedural synthesis (`companions` family, `synth`
ownership), not field recordings or downloaded assets. Parent inputs and SHA-256 hashes
are pinned in `generate-grizzly.py`; original source rights and attribution remain
in the parent audio ownership manifest.

Regenerate inside the repository exclusive build lock with
`python3 original/client/scripts/audio/generate-grizzly.py` from repository root.
The sample rate is slowed to 75%, resampled to 48 kHz, and low-pass filtered at
2400 Hz before encoding mono Opus at 40 kbit/s. Runtime pitch is unchanged.
No network inputs are used and original bear samples are preserved.
