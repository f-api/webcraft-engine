# Sweep attack audio provenance

Official Minecraft Java Edition `26.3-snapshot-7` sound files for `entity.player.attack.sweep`, taken
from Mojang's asset index (the client jar carries no sounds). On 2026-09-13 the user approved using the
pinned 26.3 client jar and the Mojang asset index textures, sounds and models wherever they are needed
(`docs/USER-REQUESTS.md`, top entry). That approval is recorded here by hash; it does not mean a licence
was obtained. Every other supplied cue keeps the disposition recorded in `../../THIRD_PARTY_AUDIO.md`.

Chain of pins, each hop verified by `scripts/audio/fetch-mojang-assets.py`:

- version JSON `https://piston-meta.mojang.com/v1/packages/9bcbca292d320f59200957e52805572be62761b4/26.3-snapshot-7.json`
  (SHA-1 `9bcbca292d320f59200957e52805572be62761b4`);
- asset index `33` (SHA-1 `7256d6797a98619a0a0579e3bb7949d2657af4ee`);
- `minecraft/sounds.json` (SHA-1 `03df9b7637bff1999da5322a5e92c57ead95a1bd`), whose
  `entity.player.attack.sweep` event lists `entity/player/attack/sweep1` … `sweep7`, each with file
  volume 0.7 and subtitle `subtitles.entity.player.attack.sweep`;
- each object below at `https://resources.download.minecraft.net/<first two hex>/<sha1>`, checked
  against the index SHA-1 and byte length, then against the SHA-256 recorded in
  `scripts/audio/mojang-asset-selection.tsv`.

| file | asset index object | sha1 (original Ogg) | sha256 (original Ogg) | bytes (Ogg) | sounds.json volume |
| --- | --- | --- | --- | --- | --- |
| `player_attack/sweep_01.webm` | `minecraft/sounds/entity/player/attack/sweep1.ogg` | `89741b2005ca27c98454e0cc000afe33b5af86fb` | `37cfe39d4d85697e1431af93f045e94ccb78578bacb6e9ce52f6fbc91d7a417f` | 6067 | 0.7 |
| `player_attack/sweep_02.webm` | `minecraft/sounds/entity/player/attack/sweep2.ogg` | `5350ba0ce6e2d5deeb53849704ce4702c0ee4a85` | `fa6ef1546275d20167e2e11591e93df5b8bfe8b87fe92b41609ce689350c4650` | 5836 | 0.7 |
| `player_attack/sweep_03.webm` | `minecraft/sounds/entity/player/attack/sweep3.ogg` | `8740a15ba2100a68975842c571d40edf970f5bef` | `270a0f370684ed5435bc8984cf50985a8c10acd32c5a6d244ab6ed9161300485` | 5866 | 0.7 |
| `player_attack/sweep_04.webm` | `minecraft/sounds/entity/player/attack/sweep4.ogg` | `98dfc1ea33b18d387dfbed5cbdc919250538c42e` | `246db3ef55af0bf7f570a085c668008382fa323fcd1187e9fba4c8f34c0c9bbc` | 5605 | 0.7 |
| `player_attack/sweep_05.webm` | `minecraft/sounds/entity/player/attack/sweep5.ogg` | `bf3558e6fb0cacdf87d0d35f1a470acbe5842af4` | `379fb59765ff3325b30c74ca51261bb52308a416440d5ccec9502b264b73f18f` | 5642 | 0.7 |
| `player_attack/sweep_06.webm` | `minecraft/sounds/entity/player/attack/sweep6.ogg` | `2b9277d2e4542d106bca65e63092c6fcaadf40ea` | `afee5cd1f4ea7c7bc40aa1ad081c83945eda95f7626d21f4499c5d07d7f8974e` | 5586 | 0.7 |
| `player_attack/sweep_07.webm` | `minecraft/sounds/entity/player/attack/sweep7.ogg` | `dcbf16528e0835b5638c782cede362aa8743fccd` | `7b732b48bb4080f7fc1b3305102786dc7b679d4510066f177d87b9d02c3d95f6` | 5934 | 0.7 |

Every output was encoded by `scripts/audio/encode-mojang-assets.sh <output>` (FFmpeg 8.0.1) through
the same strict `verify-selected-inputs.py` preflight and `loudnorm=I=-20:LRA=11:TP=-2` + true-peak
limiter chain into 48 kHz mono Opus (40 kbps VBR, WebM) as the trial family; re-encoding an existing
trial row on the same machine reproduced its committed SHA-256 byte for byte. Output SHA-256s are in
`scripts/audio/inventory-sha256.tsv`.

Runtime mapping: `SAMPLE_CATALOG.combat.sweep` (`../../SampleCatalog.ts`) lists the seven files in
sounds.json order; `entity.player.attack.sweep` (`../../SemanticSoundRegistry.ts`) plays them at the
volume-1 event gain times the file volume 0.7. Vanilla `Player.doSweepAttack` calls
`playServerSideSound(PLAYER_ATTACK_SWEEP)`, which is `level.playSound(null, x, y, z, …, PLAYERS, 1.0F,
1.0F)` (26.3-snapshot-7 javap), so there is no call-site pitch or volume change.
