# Item frame audio provenance

Official Minecraft Java Edition `26.3-snapshot-7` sound files taken from Mojang's asset index (the client jar
carries no sounds). The user explicitly approved using original Mojang assets for the End dimension, end
cities, villagers and raids and waived licensing for them, on the same basis as the title panorama
(`../../../../ui/entry/panorama/PROVENANCE.md`) and the trial spawner family (`../../trial/PROVENANCE.md`).

Chain of pins, each hop verified by `scripts/audio/fetch-mojang-assets.py`: version JSON
`9bcbca292d320f59200957e52805572be62761b4`, asset index `33` (`7256d6797a98619a0a0579e3bb7949d2657af4ee`),
`minecraft/sounds.json` (`03df9b7637bff1999da5322a5e92c57ead95a1bd`), then each object below by its index
SHA-1 and byte length and the SHA-256 recorded in `scripts/audio/mojang-asset-selection.tsv`. Encoded by
`scripts/audio/encode-mojang-assets.sh` (loudnorm, true-peak limit, 48 kHz mono Opus at the manifest bitrate).

The runtime registers the five `entity.item_frame.*` events on these files.

| file | asset index object | sha1 (original Ogg) | bytes (Ogg) | sounds.json events |
| --- | --- | --- | --- | --- |
| `end/item_frame/add_item_01.webm` | `minecraft/sounds/entity/itemframe/add_item1.ogg` | `99d745c29649c84492a072bc1c9002a51695cf81` | 4774 | entity.item_frame.add_item |
| `end/item_frame/add_item_02.webm` | `minecraft/sounds/entity/itemframe/add_item2.ogg` | `69a4a003e93004641e0ab5c2a743265d9c0ca77d` | 4671 | entity.item_frame.add_item |
| `end/item_frame/add_item_03.webm` | `minecraft/sounds/entity/itemframe/add_item3.ogg` | `95d8be2cd93f60079dace71b4393c949b48fb461` | 4801 | entity.item_frame.add_item |
| `end/item_frame/add_item_04.webm` | `minecraft/sounds/entity/itemframe/add_item4.ogg` | `0ae74c540e774f938ab085bb17207ccad1738c01` | 5019 | entity.item_frame.add_item |
| `end/item_frame/break_01.webm` | `minecraft/sounds/entity/itemframe/break1.ogg` | `55353cde7e6449249f33513f10dc43e7f6f9fe56` | 5349 | entity.item_frame.break |
| `end/item_frame/break_02.webm` | `minecraft/sounds/entity/itemframe/break2.ogg` | `4e50de01407050ed8e51722ef6f021c8e1f4ca5f` | 5410 | entity.item_frame.break |
| `end/item_frame/break_03.webm` | `minecraft/sounds/entity/itemframe/break3.ogg` | `56b0c91d5c0dbf2d9ada5cbb5404130e7e505bf9` | 5337 | entity.item_frame.break |
| `end/item_frame/place_01.webm` | `minecraft/sounds/entity/itemframe/place1.ogg` | `dc788a6b10cd82aea9fb56f4c67eccaf53656fe2` | 5860 | entity.item_frame.place |
| `end/item_frame/place_02.webm` | `minecraft/sounds/entity/itemframe/place2.ogg` | `bb56db9d9bee7e10519d8010ccd350983ee4be87` | 5453 | entity.item_frame.place |
| `end/item_frame/place_03.webm` | `minecraft/sounds/entity/itemframe/place3.ogg` | `e9b9d6122cc2aba27ba876e5d6fc9fbb44d45e1b` | 5594 | entity.item_frame.place |
| `end/item_frame/place_04.webm` | `minecraft/sounds/entity/itemframe/place4.ogg` | `dce04a1db885f8291e719977f560b96707df8147` | 4998 | entity.item_frame.place |
| `end/item_frame/remove_item_01.webm` | `minecraft/sounds/entity/itemframe/remove_item1.ogg` | `00765b2e5a821e8b22c8b555fd32d887ec805aed` | 4531 | entity.item_frame.remove_item |
| `end/item_frame/remove_item_02.webm` | `minecraft/sounds/entity/itemframe/remove_item2.ogg` | `ff85720a0188679f7e861a96ae25f6230fd895e9` | 4834 | entity.item_frame.remove_item |
| `end/item_frame/remove_item_03.webm` | `minecraft/sounds/entity/itemframe/remove_item3.ogg` | `718445399fdbe1b89eaa779c3875dece106732e0` | 4751 | entity.item_frame.remove_item |
| `end/item_frame/remove_item_04.webm` | `minecraft/sounds/entity/itemframe/remove_item4.ogg` | `e39709df8a61157842ef81742242eee76f7f435b` | 4631 | entity.item_frame.remove_item |
| `end/item_frame/rotate_item_01.webm` | `minecraft/sounds/entity/itemframe/rotate_item1.ogg` | `277e91e5e04b06ecd3ff231e8912873d2e1d5700` | 4507 | entity.item_frame.rotate_item |
| `end/item_frame/rotate_item_02.webm` | `minecraft/sounds/entity/itemframe/rotate_item2.ogg` | `c00c9f50501b1880e577822e6fe2cefa64904c8b` | 4323 | entity.item_frame.rotate_item |
| `end/item_frame/rotate_item_03.webm` | `minecraft/sounds/entity/itemframe/rotate_item3.ogg` | `202d7c719c841a48ed52cae567fdc6b35ec79ab8` | 4416 | entity.item_frame.rotate_item |
| `end/item_frame/rotate_item_04.webm` | `minecraft/sounds/entity/itemframe/rotate_item4.ogg` | `66a1ef29c6f8d833bbaaf6401b380cdc22ca4a01` | 4489 | entity.item_frame.rotate_item |
