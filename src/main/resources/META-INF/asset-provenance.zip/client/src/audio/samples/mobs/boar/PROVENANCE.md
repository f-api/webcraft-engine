# Boar voice derivatives

Seven original edits of approved repository pig recordings; no downloaded inputs.
Input origin and owner declaration are retained in `scripts/audio/selection-manifest.tsv`
under `mobs/pig/`, with committed encoded hashes pinned in `generate-boar.py`.
These inputs are the owner-provided mc-like-sounds corpus (owner declaration 2026-08-09).
No additional upstream license claim is made.

Reproduce under the repository exclusive build lock with
`python3 original/client/scripts/audio/generate-boar.py` from the repository root.
FFmpeg decodes 48 kHz pig takes, lowers pitch/rate to 80%, resamples to 48 kHz,
low-passes at 2.8 kHz, and encodes mono Opus 40 kbit/s. Attack additionally trims
and fades to a short snort. Playback rate remains 1 because pitch is baked once.
Each action has its own payload; footsteps continue using the established pig step event.
