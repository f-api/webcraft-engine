# WebCraft world capture

These six images were rendered inside WebCraft from its procedural terrain and repository assets.
They are game-world screenshots, not imported Minecraft panorama images or AI-generated scenery.

- Capture date: 2026-09-14 (Asia/Seoul).
- Source commit: `4f67af1ed35e9285f18a3609be8aca80c7185f4d` plus the existing public torch icon inputs.
- Seed: `0`, overworld; forest hills and river near spawn.
- Camera: `(0, 83.62, -16)`; player feet `(0, 82, -16)`.
- Lighting: world time `3000`; 1024 × 1024, 90° vertical field of view, aspect 1, pixel ratio 1.
- Capture: an owned isolated headless Chrome game session; pause the frame loop, hide scene overlays,
  rotate the camera, update chunk visibility for each face, render with the current animation clock,
  and read the canvas as PNG. No terrain was placed or edited for the composition.
- Face directions in game coordinates: `+Z, -X, -Z, +X, +Y, -Y` for files 0 through 5.
  Horizontal faces use up `+Y`; face 4 uses up `-Z`, face 5 uses up `+Z`.
  The runtime cube mapping and vertical upload flip remain in `../titlePanoramaSpec.ts`.
- Encoding: `cwebp 1.6.0 -q 85 -m 6 -sharp_yuv -metadata none` from the original PNG captures (lossy WebP); no resize, color grading, or painted additions.
- The temporary capture hook is not part of the distributed game. The lobby rotates these bundled
  images without creating or simulating a world in the background.

| file | SHA-256 (WebP) |
| --- | --- |
| `panorama_0.webp` | `2039b32452b5f5c6ac160454387b52d1e3357a8bdd48d1cfa97a2d99a7ad6a5e` |
| `panorama_1.webp` | `097f1c340ff400d2ff42dff2dc40765398b6deb7cb43690b757817efd3d7923a` |
| `panorama_2.webp` | `3d6471a3a1e4abc02afbf79eaa6f05f283f98eb5764cfc1b7f3a9811452ada68` |
| `panorama_3.webp` | `a8fdf91e16548c6390ed0c084753cd7d68f82b72bc6d625bb67aa6f20c50a205` |
| `panorama_4.webp` | `e0f9798cb6a1ca89d5b67266d6e070613c0eccbbc2d0689badef7c270e490a81` |
| `panorama_5.webp` | `8935142c6906af4ec075862973e2f037407dead90aebc6c2c42a56d6d3b1d636` |

## Other selectable captures

The lobby now selects one of four complete cubemaps per visit. The forest/river capture above
is joined by [snow village and ice](highlands/PROVENANCE.md) and [jungle canopy](jungle/PROVENANCE.md).
Only the selected six faces are decoded and uploaded; the other captures remain encoded.

- Fourth scene: [mature flesh colony](flesh/PROVENANCE.md), using the same selection/decode policy.
