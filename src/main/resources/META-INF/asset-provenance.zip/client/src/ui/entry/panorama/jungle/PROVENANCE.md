# WebCraft world capture — Jungle canopy and river

These six faces are actual WebCraft renders of procedural terrain and repository assets.
No terrain was placed or edited for the composition; no external panorama or AI scenery was used.

- Capture date: 2026-09-14 (Asia/Seoul).
- Source commit: `7bb77850edd597c8731c0782e3951bdfef6f0bf4` plus existing public torch icon inputs.
- Seed: `1673021364`, overworld. Ordinary local capture world; no content fixture.
- Camera: `(-11280, 95.62, -7296)`; world time `4400`.
- 1024 × 1024, 90° vertical field of view, aspect 1, pixel ratio 1.
- Owned isolated headless Chrome; pause the frame loop, hide scene overlays, orient the camera,
  update chunk visibility for each face, render with the current animation clock, and read PNG.
- Directions: `+Z, -X, -Z, +X, +Y, -Y`. Horizontal up is `+Y`; ceiling up `-Z`, floor up `+Z`.
- Encoding from original PNG: `cwebp 1.6.0 -q 85 -m 6 -sharp_yuv -metadata none`.
  No resize, color grading, or painted additions. Capture hook is not distributed.

| file | SHA-256 (WebP) |
| --- | --- |
| `panorama_0.webp` | `f2a14167d31ef3f741b6d25d0f6dd31b2d4a8901717a02efd4143c96612efd9f` |
| `panorama_1.webp` | `42eeffed3bce9a5758dc4dd45e62f1b965b663a9bc0265c15ace73828e428c81` |
| `panorama_2.webp` | `604f96235bcdd5fc5e987355e4d85bf3ea16b0e3e625b817d9359e4cd78ab314` |
| `panorama_3.webp` | `60f0ccb46bca84dad73e0b6ff21c09313f2fa174497473f08194145549d946f9` |
| `panorama_4.webp` | `2b437a2a5b2dd5bf3d53bae714832281ddc9180c3589e085cea23448aaa8d334` |
| `panorama_5.webp` | `5278a4ac7f7433fbf93b8846da06f624e4140bcd365991bb6d611a5b9a732789` |
