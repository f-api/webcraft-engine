# WebCraft world capture — Snow village and ice

These six faces are actual WebCraft renders of procedural terrain and repository assets.
No terrain was placed or edited for the composition; no external panorama or AI scenery was used.

- Capture date: 2026-09-14 (Asia/Seoul).
- Source commit: `7bb77850edd597c8731c0782e3951bdfef6f0bf4` plus existing public torch icon inputs.
- Seed: `0`, overworld. Ordinary local capture world; no content fixture.
- Camera: `(-848, 75.62, 3568)`; world time `3000`.
- 1024 × 1024, 90° vertical field of view, aspect 1, pixel ratio 1.
- Owned isolated headless Chrome; pause the frame loop, hide scene overlays, orient the camera,
  update chunk visibility for each face, render with the current animation clock, and read PNG.
- Directions: `+Z, -X, -Z, +X, +Y, -Y`. Horizontal up is `+Y`; ceiling up `-Z`, floor up `+Z`.
- Encoding from original PNG: `cwebp 1.6.0 -q 85 -m 6 -sharp_yuv -metadata none`.
  No resize, color grading, or painted additions. Capture hook is not distributed.

| file | SHA-256 (WebP) |
| --- | --- |
| `panorama_0.webp` | `195e8b13d9021bcb6f62ac9a77a9c5d45419f7e3fb40cff94d3fa07f91a7696b` |
| `panorama_1.webp` | `22488bc4aa18b3b23050646db3e63f11f6cf396b79c5e9ce41f24b073b52235e` |
| `panorama_2.webp` | `58e6df80fefe89010001f622bebfd64f02a1a755970783dff445cce75f9d858b` |
| `panorama_3.webp` | `56a20de58e54cdf89ce2349693dba55218c79e3d29d79e66ee2a9d183657adad` |
| `panorama_4.webp` | `22d249903342466b03d81069ce98bd8d140e75937a6f5e433dd258b6533ad096` |
| `panorama_5.webp` | `c363324c7661e7a5bb0120577063f08c2d32b19df6e955f0d9dca38c3af8e177` |
